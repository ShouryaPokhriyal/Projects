﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Globalization;
using System.IO;
using System.Configuration;
using Newtonsoft.Json;

namespace FileDeleterApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Configuration: Set the folder path and number of days
            string folderPath = ConfigurationManager.AppSettings["FileDirectory"];

            //@"D:\Shourya\DeleteFiles30days";
            string days = ConfigurationManager.AppSettings["NumberOfDays"];

            // Validate folder path
            if (!Directory.Exists(folderPath))
            {
                Console.WriteLine($"The specified folder path does not exist: {folderPath}");
                return;
            }

            // Calculate the cutoff date
            DateTime cutoffDate = DateTime.Now.AddDays(Convert.ToInt32(days));

            // Get all files in the folder
            string[] files = Directory.GetFiles(folderPath);

            foreach (string file in files)
            {
                try
                {
                    // Get the file creation date
                    DateTime fileCreationDate = File.GetCreationTime(file);

                    string [] filename_split  = Path.GetFileNameWithoutExtension(file).Split("_");
                    string date_Split = filename_split[1];
                    

                    if (Convert.ToDateTime(date_Split) < cutoffDate.Date)
                    {
                        File.Delete(file);
                        Console.WriteLine($"Deleted file: {file}");
                    }
      
                    // Check if the file is older than the cutoff date
                    else if (fileCreationDate < cutoffDate)
                    {
                        // Delete the file
                        File.Delete(file);
                        Console.WriteLine($"Deleted file: {file}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing file {file}: {ex.Message}");
                }
            }

            
        }
    }
}
